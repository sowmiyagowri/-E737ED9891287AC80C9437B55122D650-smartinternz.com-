class Bankaccount: 

 def __init__(self,account_holder,account_number,balance):
   self.account_holder=account_holder
   self.account_number=account_holder
  self.balance=balance
def deposit(self,ammount):
  if amount>0:
      self.balance+=ammount
    def withdraw(self,amount):
      if amount>0 and self.balance>=amount:
        print(f'withdraw ${amount}.new balance:$(self.account_number}')
      else:
        print('insufficient funds or invalid amount for withdrawal.')
        def check_balance(self):
          print(f'Account holder:{self.account_holder}')
          print(f'Account number: {self.account_number}')
          print(f'balance:${self.balance}')


account1=BankAccount('sanjay','123456789',1000.0)

account1.check_balance()  account1.deposit(500.0)
account1.withdraw(200.0)
account1.check_balance()